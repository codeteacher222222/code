var sans = {};
sans.ready = false;
sans.image = new Image();
sans.image.src = "images/sans.png";
sans.image.onload = function () {
    sans.ready = true;
};
sans.reset = function () {
    sans.x = 32 + (Math.random() * (canvas.width - 64));
    sans.y = 32 + (Math.random() * (canvas.height - 64));
};

sans.render = function(){
  if (sans.ready) {
      ctx.drawImage(sans.image, sans.x, sans.y, 100, 100);
  }
}
