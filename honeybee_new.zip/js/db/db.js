var systemDB;
var dataset;
$(document).ready(function(){
    initDatabase();
    $("#btn_insert").click(function(){
        insertDB(systemDB);
        selectAllList(systemDB);
        $(".btn_set").hide();
    });
    $(".btn_set").hide();
    $("#boardlist").hide();

});


function initDatabase(){
    if(!window.openDatabase){
        alert("현재 브라우저는 Web SQL Database를 지원하지 않습니다.");
    }else {
        var shortName = "Board";
        var version = "1.0";
        var displayName = "Board DB";
        var maxSize = 1024 * 64;
        var db = openDatabase(shortName, version, displayName, maxSize);
        //alert("현재 브라우저는 Web SQL Database를 지원합니다.");
    }

    createTable(db);
    //insertTestDB(db);
    systemDB = db;
}

function createTable(db){
    var strCreate = "CREATE TABLE IF NOT EXISTS honeybee"
                + " (idx INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
                + " username TEXT NOT NULL,"
                + " score TEXT NOT NULL,"
                + " regdate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)";
    db.transaction(function(tx){
        console.log(tx.executeSql(strCreate));
        console.log(tx);
        console.log(strCreate);
    });
}

function selectAllList(db){
    var strSql = "SELECT * FROM honeybee ORDER BY score DESC";
    $("#boardlist").html("");
    db.transaction(function (tx){
        tx.executeSql(strSql, [], function(tx, result){
            dataset = result.rows;
            var str = "<ol>";
            if(dataset.length > 0){
                for(var i = 0, item = null; i < dataset.length; i++){
                    item = dataset.item(i);
                    str += "<li>"+item['username'];
                    str += " : "+item['score'];
                    str += " : "+item['regdate'];
                    str += "</li>";
                }
            }else {
                str += "리스트 내용이 없습니다.";
            }
            str += "</ol>";
            $("#boardlist").html(str);
        });
    });
}

function insertDB(db){
    var strSql = "INSERT INTO honeybee(username, score) values(?, ?)";
    var username = $("#username").val().trim();
    //var score = score;

    if(username === "" ){
        alert("글을 적어주세요.");
        $("#username").focus();
        return;
    }

    db.transaction(function(tx){
        tx.executeSql(strSql, [username, score], loadAndReset, errorHandler);
    });
}
function loadAndReset(){
    resetForm();
    selectAllList(systemDB);
}

function resetForm(){
    $("#username").val("");
}

function errorHandler(error){
    alert("Error: "+error.message+" Code "+error.code+")");
}
