var Thyme = {};
Thyme.ready = false;
Thyme.image = new Image();
Thyme.image.src = "images/Thyme.png";
Thyme.image.onload = function () {
    Thyme.ready = true;
};
Thyme.reset = function () {
    Thyme.x = 32 + (Math.random() * (canvas.width - 64));
    Thyme.y = 32 + (Math.random() * (canvas.height - 64));
};

Thyme.render = function(){
  if (Thyme.ready) {
      ctx.drawImage(Thyme.image, Thyme.x, Thyme.y, 60, 60);
  }
}
