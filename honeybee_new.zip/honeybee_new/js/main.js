var isGame=true;
function GameOver(){
  ctx.fillStyle = "red";
  ctx.font="bold 50pxArial, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText('GAMEOVER ', canvas.width - 250, 200);
  isGame=false;
};

addEventListener("keydown", function (e) {
    keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) {
    delete keysDown[e.keyCode];
}, false);

function render () {
    var delta = Date.now() - lastUpdateTime;
    if (acDelta > msPerFrame) {
        acDelta = 0;

        back.render();
        bee.render();
        bee2.render();
        flower.render();
        flower2.render();
        Thyme.render();

        frame++;
        if (frame >= 3) {
            frame = 0;
        }
    } else {
        acDelta += delta;
    }

    // Score
    ctx.fillStyle = "rgb(250, 250, 250)";
    ctx.font = "bold 20px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    ctx.fillText("SCORE: " + score, canvas.width / 2, 10);

        // time
    times++;
    ctx.fillStyle = "black";
    ctx.textAlign = "right";
    ctx.fillText('TIME: ' + Math.round(times / 100), canvas.width - 10, 10);
    ctx.fillStyle = "red";
    ctx.textAlign = "right";
    ctx.fillText('HP: ' + HP, canvas.width - 10, 50);
    ctx.fillStyle = "black";
    ctx.textAlign = "right";
    ctx.fillText('Charge: ' + Math.round(charge) +'/7', canvas.width - 10, 90);
};
function reset () {
    bee2.reset();
    flower.reset();
    flower2.reset();
    Thyme.reset();
};
function update () {
    bee.update();
    bee2.update();
};
function main () {

  if(isGame)
  {

    update();
    render();
    requestAnimationFrame(main);
  }
  else
  {
    GameOver();
  }
};
    reset();
main();
