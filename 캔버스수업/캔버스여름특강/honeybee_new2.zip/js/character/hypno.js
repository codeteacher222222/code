var hypno = {};
hypno.ready = false;
hypno.image = new Image();
hypno.image.src = "images/hypno.png";
hypno.image.onload = function () {
    hypno.ready = true;
};
hypno.reset = function () {
    hypno.x = 32 + (Math.random() * (canvas.width - 64));
    hypno.y = 32 + (Math.random() * (canvas.height - 64));
};

hypno.render = function(){
  if (hypno.ready) {
      ctx.drawImage(hypno.image, hypno.x, hypno.y, 60, 60);
  }
}
