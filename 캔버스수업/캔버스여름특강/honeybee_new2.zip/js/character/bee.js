var bee = {};
bee.x = canvas.width / 2;
bee.y = canvas.height / 2;
bee.speed = 5;
bee.image = new Image();
bee.image.src = "images/bee.png";
bee.image.onload = function () {
    bee.ready = true;
};
bee.ready = false;
bee.offset = 0;

bee.update = function () {
    // up
    if (38 in keysDown) {
        bee.y -= bee.speed;
        bee.offset = 144;
    }
    // down
    if (40 in keysDown) {
        bee.y += bee.speed;
        bee.offset = 0;
    }
    //left
    if (37 in keysDown) {
        bee.x -= bee.speed;
        bee.offset = 48;
    }
    // right
    if (39 in keysDown) {
        bee.x += bee.speed;
        bee.offset = 96;
    }

    // boundery limit
    if (bee.x <= 0) {
        bee.x = 0;
    }
    if (bee.x >= canvas.width - 32) {
        bee.x = canvas.width - 32;
    }
    if (bee.y <= 0) {
        bee.y = 0;
    }
    if (bee.y >= canvas.height - 48) {
        bee.y = canvas.height - 48;
    }

    // collution
    if (bee.x <= (flower.x + 16)
        && bee.x >= (flower.x - 16)
        && bee.y <= (flower.y + 24)
        && bee.y >= (flower.y - 24)) {
          HP++;
        reset();
        hitSound.play();
        ++score;
    }
    if (bee.x <= (flower2.x + 30)
        && bee.x >= (flower2.x - 30)
        && bee.y <= (flower2.y + 30)
        && bee.y >= (flower2.y - 30)) {
          --charge;
          if(charge <0)
          {
            charge = 0;
          }
        reset();
      --HP;
      if(HP<0)
      GameOver();
    }
    if (bee.x <= (Thyme.x + 30)
        && bee.x >= (Thyme.x - 30)
        && bee.y <= (Thyme.y + 30)
        && bee.y >= (Thyme.y - 30)) {
          ++charge;
          if(charge == 7)
          {
            score += 10;
            charge = 0;
          }
        reset();
        hitSound.play();
    }

    if (bee.x <= (hypno.x + 16)
        && bee.x >= (hypno.x - 16)
        && bee.y <= (hypno.y + 24)
        && bee.y >= (hypno.y - 24)) {
        bee.speed=-15;

        hitSound.play();
    }
    if (bee.x <= (Aloe.x + 16)
        && bee.x >= (Aloe.x - 16)
        && bee.y <= (Aloe.y + 24)
        && bee.y >= (Aloe.y - 24)) {
        HP+=1;

        hitSound.play();
    }
    if (bee.x <= (DoomShroom.x + 16)
        && bee.x >= (DoomShroom.x - 16)
        && bee.y <= (DoomShroom.y + 24)
        && bee.y >= (DoomShroom.y - 24)) {
      HP-=100;
reset();
        hitSound.play();
    }
};

bee.render = function(){
  if (bee.ready) {
      ctx.drawImage(bee.image, frame * 32, bee.offset, 32, 48, bee.x, bee.y, 32, 48);
  }
}
