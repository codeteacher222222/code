var Ice = {};
Ice.ready = false;
Ice.image = new Image();
Ice.image.src = "images/Iceberg.png";
Ice.image.onload = function () {
    Ice.ready = true;
};
Ice.reset = function () {
    Ice.x = 32 + (Math.random() * (canvas.width - 64));
    Ice.y = 32 + (Math.random() * (canvas.height - 64));
};

Ice.render = function(){
  if (Ice.ready) {
      ctx.drawImage(Ice.image, Ice.x, Ice.y, 60, 60);
  }
}
