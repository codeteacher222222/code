var Aloe = {};
Aloe.ready = false;
Aloe.image = new Image();
Aloe.image.src = "images/Aloe.png";
Aloe.image.onload = function () {
    Aloe.ready = true;
};
Aloe.reset = function () {
    Aloe.x = 32 + (Math.random() * (canvas.width - 64));
    Aloe.y = 32 + (Math.random() * (canvas.height - 64));
};

Aloe.render = function(){
  if (Aloe.ready) {
      ctx.drawImage(Aloe.image, Aloe.x, Aloe.y, 60, 60);
  }
}
