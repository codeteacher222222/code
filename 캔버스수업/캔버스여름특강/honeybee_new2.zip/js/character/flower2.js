var flower2 = {};
flower2.ready = false;
flower2.image = new Image();
flower2.image.src = "images/flower2.png";
flower2.image.onload = function () {
    flower2.ready = true;
};
flower2.reset = function () {
    flower2.x = 32 + (Math.random() * (canvas.width - 64));
    flower2.y = 32 + (Math.random() * (canvas.height - 64));
};

flower2.render = function(){
  if (flower2.ready) {
      ctx.drawImage(flower2.image, flower2.x, flower2.y, 60, 60);
  }
}
