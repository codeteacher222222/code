var Tall = {};
Tall.ready = false;
Tall.image = new Image();
Tall.image.src = "images/Tallnuts.png";
Tall.image.onload = function () {
    Tall.ready = true;
};
Tall.reset = function () {
    Tall.x = 32 + (Math.random() * (canvas.width - 64));
    Tall.y = 32 + (Math.random() * (canvas.height - 64));
};

Tall.render = function(){
  if (Tall.ready) {
      ctx.drawImage(Tall.image, Tall.x, Tall.y, 80, 100);
  }
}
