var DoomShroom = {};
DoomShroom.ready = false;
DoomShroom.image = new Image();
DoomShroom.image.src = "images/DoomShroom.png";
DoomShroom.image.onload = function () {
    DoomShroom.ready = true;
};
DoomShroom.reset = function () {
    DoomShroom.x = 32 + (Math.random() * (canvas.width - 64));
    DoomShroom.y = 32 + (Math.random() * (canvas.height - 64));
};

DoomShroom.render = function(){
  if (DoomShroom.ready) {
      ctx.drawImage(DoomShroom.image, DoomShroom.x, DoomShroom.y, 60, 60);
  }
}
