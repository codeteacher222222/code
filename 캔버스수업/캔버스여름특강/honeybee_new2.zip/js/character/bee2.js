var bee2 = {};
bee2.x = canvas.width / 2;
bee2.y = canvas.height / 2;
bee2.speed = 1.9;
bee2.image = new Image();
bee2.image.src = "images/bee2.png";
bee2.image.onload = function () {
    bee2.ready = true;
};
bee2.ready = false;
bee2.offset = 0;

bee2.update = function () {
  // up
  if (bee.y<bee2.y) {
      bee2.y -= bee2.speed;
      bee2.offset = 144;
  }
  // down
  if (bee.y>bee2.y) {
      bee2.y += bee2.speed;
      bee2.offset = 0;
  }
  //left
  if (bee.x<bee2.x) {
      bee2.x -= bee2.speed;
      bee2.offset = 48;
  }
  // right
  if (bee.x>bee2.x) {
      bee2.x += bee2.speed;
      bee2.offset = 96;
  }

  // boundery limit
  if (bee2.x <= 0) {
      bee2.x = 0;
  }
  if (bee2.x >= canvas.width - 32) {
      bee2.x = canvas.width - 32;
  }
  if (bee2.y <= 0) {
      bee2.y = 0;
  }
  if (bee2.y >= canvas.height - 48) {
      bee2.y = canvas.height - 48;
  }

  // collution
  if (bee2.x <= (bee.x + 16)
      && bee2.x >= (bee.x - 16)
      && bee2.y <= (bee.y + 24)
      && bee2.y >= (bee.y - 24)) {
      reset();
      --charge;
      if(charge<0)
      {
        charge = 0;
      }
    --HP;
    if(HP<0)
    GameOver();
  }
  if (bee2.x <= (Ice.x + 30)
        && bee2.x >= (Ice.x - 30)
        && bee2.y <= (Ice.y + 30)
        && bee2.y >= (Ice.y - 30)) {
          bee2.speed=0;
        
        hitSound.play();
      }
  if (bee2.x <= (Tall.x + 40)
      && bee2.x >= (Tall.x - 40)
      && bee2.y <= (Tall.y + 50)
      && bee2.y >= (Tall.y - 50)) {

        bee2.reset();
      hitSound.play();
  }
  if (bee2.x <= (hypno.x + 30)
        && bee2.x >= (hypno.x - 30)
        && bee2.y <= (hypno.y + 30)
        && bee2.y >= (hypno.y - 30)) {
          bee2.speed= -15;
        bee2.reset();
        hitSound.play();
      }
};
bee2.reset = function () {
    bee2.x = 32 + (Math.random() * (canvas.width - 64));
    bee2.y = 32 + (Math.random() * (canvas.height - 64));
};
bee2.render = function(){
  if (bee2.ready) {
      ctx.drawImage(bee2.image, frame * 32, bee2.offset, 32, 48, bee2.x, bee2.y, 32, 48);
  }
}
