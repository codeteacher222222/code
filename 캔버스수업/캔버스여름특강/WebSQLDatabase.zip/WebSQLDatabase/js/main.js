var systemDB;
var dataset;

$(document).ready(function(){
    initDatabase();
    $("#btn_insert").click(function(){
        insertDB(systemDB);
    });

    $("body").on("click", ".btn_edit", function(){
        var no = $(this).data("no");
        var idx = $(this).data("idx");
        $("#id").val(idx);
        loadRecord(no);
    });
    // 업데이트
    $("#btn_update").click(function(){
        updateDB(systemDB);
    });

    //삭제
    $("body").on("click", ".btn_delete", function(){
        var idx = $(this).data("idx");
        deleteDB(systemDB, idx);
        selectAllList(systemDB);

    });

    // 테이블 삭제
    $("#btn_drop").click(function(){
        dropTable(systemDB);
    });
    //글지우기
    $("#btn_reset").click(resetForm);
});


function initDatabase(){
    if(!window.openDatabase){
        alert("현재 브라우저는 Web SQL Database를 지원하지 않습니다.");
    }else {
        var shortName = "Board";
        var version = "1.0";
        var displayName = "Board DB";
        var maxSize = 1024 * 64;
        var db = openDatabase(shortName, version, displayName, maxSize);
        //alert("현재 브라우저는 Web SQL Database를 지원합니다.");
    }

    createTable(db);
    //insertTestDB(db);
    selectAllList(db);
    systemDB = db;
}

function createTable(db){
    var strCreate = "CREATE TABLE IF NOT EXISTS tbl_board"
                + " (idx INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
                + " username TEXT NOT NULL,"
                + " content TEXT NOT NULL,"
                + " regdate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)";
    db.transaction(function(tx){
        console.log(tx.executeSql(strCreate));
        console.log(tx);
        console.log(strCreate);
    });
}

function insertTestDB(db){
    db.transaction(function(tx){
        tx.executeSql("INSERT INTO tbl_board(username, content) values('test', '1번째 글입니다.')");
        tx.executeSql("INSERT INTO tbl_board(username, content) values('test', '2번째 글입니다.')");
        tx.executeSql("INSERT INTO tbl_board(username, content) values('test', '3번째 글입니다.')");
    });
}

function selectAllList(db){
    var strSql = "SELECT * FROM tbl_board ORDER BY idx DESC";
    $("#boardlist").html("");
    db.transaction(function (tx){
        tx.executeSql(strSql, [], function(tx, result){
            dataset = result.rows;
            var str = "<ol>";
            if(dataset.length > 0){
                for(var i = 0, item = null; i < dataset.length; i++){
                    item = dataset.item(i);
                    str += "<li>"+item['username'];
                    str += " : "+item['content'];
                    str += " : "+item['regdate'];
                    str += "&nbsp;&nbsp;&nbsp;&nbsp;";
                    str += "<span class='btn_edit' data-no='"+i;
                    str += "' data-idx='"+item['idx']+"'>edit</span>";
                    str += "&nbsp;&nbsp;&nbsp;&nbsp;";
                    str += "<span class='btn_delete' data-no='"+i;
                    str += "' data-idx='"+item['idx']+"'>delete</span>";
                    str += "</li>";
                }
            }else {
                str += "리스트 내용이 없습니다.";
            }
            str += "</ol>";
            $("#boardlist").html(str);
        });
    });
}

function insertDB(db){
    var strSql = "INSERT INTO tbl_board(username, content) values(?, ?)";
    var username = $("#username").val().trim();
    var content = $("#content").val().trim();

    if(username === "" || content === ""){
        alert("글을 적어주세요.");
        $("#username").focus();
        return;
    }

    db.transaction(function(tx){
        tx.executeSql(strSql, [username, content], loadAndReset, errorHandler);
    });
}

function loadAndReset(){
    resetForm();
    selectAllList(systemDB);
}

function resetForm(){
    $("#username").val("");
    $("#content").val("");
}

function errorHandler(error){
    alert("Error: "+error.message+" Code "+error.code+")");
}

function loadRecord(no) {
    var item = dataset.item(no);
    $("#username").val((item['username']).toString());
    $("#content").val((item['content']).toString());
}

function updateDB(db){
    var strSql = "UPDATE tbl_board SET username = ?, content = ? WHERE idx = ?";
    var username = $("#username").val().trim();
    var content = $("#content").val().trim();
    var idx = $("#id").val();

    if(username === "" || content === "" || Number(idx) <= 0){
        alert("글을 적어주세요.");
        $("#username").focus();
        return;
    }

    db.transaction(function(tx){
        tx.executeSql(strSql, [username, content, Number(idx)], loadAndReset, errorHandler);
    });
}

function deleteDB(db, idx){
    if(Number(idx) <= 0){
        alert("삭제할 글을 선택해주세요.");
        return;
    }

    if(!confirm("삭제를 하겠습니까?")){
        return;
    }

    var strSql = "DELETE FROM tbl_board WHERE idx=?";
    db.transaction(function (tx){
        tx.executeSql(strSql, [Number(idx)], loadAndReset, errorHandler);
    });
}

function dropTable(db){
    if(!confirm("테이블을 삭제를 하겠습니까?")){
        return;
    }
    var strSql = "DROP TABLE tbl_board";
    db.transaction(function(tx){
        tx.executeSql(strSql, [], loadAndReset, errorHandler);
    });
    resetForm();
    initDatabase();
}
